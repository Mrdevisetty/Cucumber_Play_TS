import { Given, Then } from '@cucumber/cucumber';
import axios from 'axios';
import Ajv from 'ajv';
import addFormats from 'ajv-formats';


const ajv = new Ajv();
addFormats(ajv);

let response: any;
let dynamicSchema: any;

Given('Send a request to the countries API', async function () {
  try {
    response = await axios.get('https://restcountries.com/v3.1/all');
    if (response.data.length > 0) {
      dynamicSchema = generateSchema(response.data[0]);
    }
  } catch (error) {
    console.error('Error fetching API data:', error);
    throw error; // Rethrow the error to fail the test
  }
});

Then('the response should match the expected schema', function () {
  console.log('Response status:', response.status);

  // Validate using the generated dynamic schema
  const validate = ajv.compile(dynamicSchema);
  const valid = validate(response.data);

  if (!valid) {
    console.error('Schema validation errors:', validate.errors);
    throw new Error('Response schema validation failed');
  } else {
    console.log('Response schema is valid');
  }
});

Then('the number of countries should be counted', function () {
  const numberOfCountries = response.data.length;
  console.log(`Number of countries: ${numberOfCountries}`);
});

Then('I should locate South Africa', function () {
  const southAfrica = response.data.find((country: any) => country.name.common === 'South Africa');
  if (southAfrica) {
    console.log('South Africa found:', southAfrica.name.common);
  } else {
    console.log('South Africa not found');
  }
});

Then('identify its official languages', function () {
  const southAfrica = response.data.find((country: any) => country.name.common === 'South Africa');
  if (southAfrica) {
    const languages = southAfrica.languages;
    console.log('Official languages of South Africa:', languages);
  } else {
    console.log('South Africa not found, so no languages to display');
  }
});

// Helper function to generate schema dynamically
function generateSchema(sample: any) {
  return {
    type: 'object',
    properties: Object.keys(sample).reduce((acc: any, key: string) => {
      acc[key] = {
        type: typeof sample[key] === 'object' && !Array.isArray(sample[key]) ? 'object' : typeof sample[key]
      };
      return acc;
    }, {}),
    required: Object.keys(sample)
  };
}
