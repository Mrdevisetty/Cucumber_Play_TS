
import {Browser, chromium, Page,expect } from "@playwright/test";
import {Before,After,Given,When,Then,setDefaultTimeout} from  "@cucumber/cucumber";
setDefaultTimeout(60 * 1000);
let browser: Browser,page: Page;
let isBlocked: boolean ;  
let btmPerformer:any = [];
let chrgPercntge:any = [];
let obj: any;



Given('User Navigates to the Portal', async function(){
  browser = await chromium.launch({headless: false});
  if(browser) page = await browser.newPage();
  await page.goto('https://www.marketwatch.com/investing/index/spx');
  await page.waitForTimeout(5000);
  isBlocked=  (await page.title()).includes('marketwatch.com');
  if(!isBlocked){
  await page.screenshot({ path: 'screenshot_1.png' })
  console.log('Page Tile: ',await page.title());
  await expect(page).toHaveTitle('SPX | S&P 500 Index Overview | MarketWatch');
  await page.screenshot({ path: 'screenshot_2.png' });
  }
  else{   
    console.log('Site Access has been blocked');

  }
  async function chkTitle(){

    return (await page.title()).includes('marketwatch.com');

  }
 });


When('User clicks on Market Watch tab', async function () {
  if(!isBlocked){
  await page.frameLocator('iframe[title="SP Consent Message"]').getByLabel('YES, I AGREE').click();
  await page.getByLabel('Become a More Confident').getByRole('button').click();
  await page.getByRole('link', { name: 'MarketWatch', exact: true }).click();
  }
  else{
    console.log('Site Access has been blocked');
  }
 });
 
Then('Print first {int} Artical names in console', async function (articlesCnt: number ) {

  if(!isBlocked){
     for (let i=1;i<=articlesCnt;i++){

        const artcles = await page.$('//div[@class = "latestNews__wrapper j-scrollViewport"]//li['+i+']//a/span');
        const artleName = await (await artcles?.getProperty('textContent'));
        console.log('Artical '+i+' Title  : ',artleName);
    }
  }
  else{
    console.log('Site Access has been blocked');
   }
         
  });


Then('list the top {int} worst performing stocks indexed by the change percentage', async function (count: number) {

  await page.frameLocator('iframe[title="SP Consent Message"]').getByLabel('YES, I AGREE').click();
  await page.getByLabel('Become a More Confident').getByRole('button').click();

  if(!isBlocked){
   let bottomPerformers =  page.locator('//div[@class="element element--table overflow--table ByIndexDecliners"]/table/tbody/tr');
   console.log('bottomPerformers', await bottomPerformers.count());

   for(let i=0;i<=await bottomPerformers.count();i++){
    
    let indexName:any = await page.locator('//div[@class="element element--table overflow--table ByIndexDecliners"]/table/tbody/tr['+i+']/td[1]').textContent();
    let chgpercntgxt: any = await page.locator('//div[@class="element element--table overflow--table ByIndexDecliners"]/table/tbody/tr['+i+']/td[4]').textContent();
    chrgPercntge.push(parseFloat(chgpercntgxt));
    var sortedArray: number[] = chrgPercntge.sort((n1:any,n2:any) => n1 - n2);
    obj = {"index" : indexName, "chgpercntg": parseFloat(chgpercntgxt) };
    btmPerformer.push(obj);

    for (let j = 0; j < count; j++) {
      let result = btmPerformer.filter((obj:any) => {
        return obj.chgpercntg === sortedArray[j];
      });
      console.log('Bottom Performer Index: '+i+': ',result[0].index)
  }
  }
  
  }
  else{
    console.log('Site Access has been blocked');
    await page.close();
  } 

  //await browser.close();


  });


