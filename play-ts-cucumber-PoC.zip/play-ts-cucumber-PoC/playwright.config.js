import { defineConfig } from '@playwright/test';

export default defineConfig({
  globalTimeout: 60 * 60 * 1000,
  use: {
    headless: false,    
    launchOptions: {
      // 1
      args: ["--start-maximized"],
    },
  }
});